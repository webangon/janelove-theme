<?php

class Jl_Theme_Actions
{
    /**
     * contructor for do action hook add_action( 'save_post', 'jl_save_meta' );
     */

    public function __construct()
    {
        add_action('jl_popular_topics', array(&$this, 'jl_popular_topics'));
        add_action('jl_top_rated', array(&$this, 'jl_top_rated'));
        add_action('jl_new_course', array(&$this, 'jl_new_course'));
        add_action('jl_counter', array(&$this, 'jl_counter'));
        add_action('jl_hero', array(&$this, 'jl_hero'));
        add_action('jl_author', array(&$this, 'jl_author'));

    }

    /**
     * course taxonomy with links
     * @return string
     */
    
    private function show_taxonomy_link(){

            global $post;
            $output='';        
            $ids=  'course-category';                   
            $terms = wp_get_post_terms($post->ID, $ids);        
            $separator = ', ';
      
    }

    /**
     * author image with archive link
     * @return string
     */
    
    private function author_img(){

            return'<span class="post-info-author">
                '.get_avatar( get_the_author_meta( 'ID' ), 50 ).'<span class="inner-info-author leffect-1">'.get_the_author_posts_link().'</span>
            </span>';
    }

    /**
     * hero with title, sub-title and course search
     * @return string
     */
    
    public function jl_hero(){
        echo '
         <div class="xl-hero">
         <div class="container">
            <div class="col-lg-6">
            <h2>Discover a new way of learning</h2>
            <p>Competently underwhelm synergistic total linkage vis-a-vis progressive networks. Globally strategize backward-compatible </p>
            <form id="searchform" action="'.home_url('/').'" method="get">
                    <input class="inlineSearch" type="text" name="s" value="" placeholder="Search courses" />
                    <input type="hidden" name="post_type" value="courses" />
                    <input class="inlineSubmit" id="searchsubmit" type="submit" alt="Search" value="Search" />
            </form>
            </div>
         </div>
         </div>
        ';
    }

    /**
     * list all author with image social links
     * @return string
     */
    
    public function jl_author(){
 
        $users = get_users();
        foreach ($users as $author) {

            $nickname_o = '<h3 class="name">'.$author->display_name.'</h3>';   
            $img = '<div class="auth-avatar"><img src="'.get_avatar_url( $author->ID ).'"></div>';

            $out.= '
                <div class="items">
                    <div class="inner">
                        '.$img.'
                        '.$nickname_o.'
                    </div>
                </div>
            ';
        }
        echo '<div class="container testi-title author-wrap"><div class="col-lg-12"><h2>Our Popular<br>creator</h2><p>Phosfluorescently morph ubiquitous </p></div></div>';
        echo '<div class="container xl-author"><div class="author-carousel owl-carousel owl-theme">'.$out.'</div></div>';

    }

    /**
     * shows counter
     * @return string
     */
    
    public function jl_counter(){

        $out.= '
            <div class="items col-lg-4">
                <div class="inner">
                    '.get_theme_mod('fcounter').'
                </div>
            </div>
            <div class="items col-lg-4">
                <div class="inner">
                    '.get_theme_mod('scounter').'
                </div>
            </div>
            <div class="items col-lg-4">
                <div class="inner">
                    '.get_theme_mod('tcounter').'
                </div>
            </div>                                
        ';
   
        echo '<div class="container xl-counter">'.$out.'</div>';
    }

    /**
     * popular course
     * @return string
     */

    public function jl_popular_topics()
    {

        $terms = get_terms( array(
            'taxonomy' => 'course-category',
            'hide_empty' => false,
        ) );

        if ( ! empty( $terms ) && is_array( $terms ) ) {

            foreach ( $terms as $term ) {
                $out       = '
                    <div class="items col-lg-3">
                        <div class="inner">
                            <a class="fullink" href="'. get_term_link( $term ).'"></a>
                            <div class="content">
                                '.$term->name.'
                            </div>
                        </div>
                    </div>
                ';
                $content .= $out;
            }
        }

        $html = '
            <div class="popular-topic">
                <div class="container">
                   <div class="title main">
                        <h2>Popular Topics</h2>
                        <a href="#">Show All</a>
                   </div>
                </div>
                <div class="container">
                    ' . $content . '
                </div>
            </div>
        ';
        echo $html;
    }

    /**
     * build course with passed argument
     * @param  string $trending filter by rating
     * @return sting 
     */
    public function build_query ($trending){

            $query_args = array(
                'post_type' => 'courses',
                'posts_per_page' => 3,
            );
            if ($trending){
                $query_args['meta_key'] = 'jl_rating';
                $query_args['orderby'] = 'meta_value_num';
            }

            $loop = new \WP_Query($query_args);
            ob_start();
            if ($loop->have_posts()) : ?>
                    <?php while ($loop->have_posts()) : $loop->the_post();
                    $rating = get_post_meta( get_the_ID(), 'jl_rating', true );
                    $price = get_post_meta( get_the_ID(), 'jl_price', true );
                    $discount = get_post_meta( get_the_ID(), 'jl_discount', true );
                    $has_price = $price ? '<span class="price">'.$price.'</span>' : '';
                    $has_discount = $discount ? '<span class="discount">'.$discount.'</span>' : '';
                    ?>
                    <div class="col-lg-4">
                        <div class="blog-img-text">
                            <?php if ( has_post_thumbnail()){
                                the_post_thumbnail('full');
                            }?>   
                            <div class="topmeta"> 
                                <?php echo $this->show_taxonomy_link();?>
                                <span class="tscore"><span style="width: <?php echo $rating;?>0%"></span></span>
                            </div>                     
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <?php echo $this->author_img();?>
                            <div class="bottom-meta">
                                <div class="price"><?php echo $has_discount.$has_price;?></div>
                                <div class="rmbtn"><a href="<?php the_permalink(); ?>">Watch Preview</a></div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>

                    <?php wp_reset_postdata(); ?>
                    
            <?php endif;
            return ob_get_clean();

    }

    /**
     * top rated course
     * @return sting sorted by rating metabox
     */
    
    public function jl_top_rated()
    {    

            $out = '
                <div class="container postblock">
                   <div class="title main">
                        <h2>Trending Topics</h2>
                        <a href="#">Show All</a>
                   </div>
                </div>
                <div class="container">
                '.$this->build_query($type='yes').'
                </div>
            ';

            echo $out;

    }

    /**
     * [jl_new_course description]
     * @return [type] [description]
     */
    
    public function jl_new_course()
    {    

            $out = '
                <div class="container">
                   <div class="title main">
                        <h2>Popular Topics</h2>
                        <a href="#">Show All</a>
                   </div>
                </div>
                <div class="container">
                '.$this->build_query($type='').'
                </div>
            ';

            echo $out;

    }



}

new Jl_Theme_Actions();


