<?php
/*
Plugin Name: Janelove Addon
Plugin URI: https://webangon.com/
Description: Janelove Addon. 
Author: Ashraf
Author URI: https://webangon.com
Version: 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit;
define( 'PLUG_DIR', dirname(__FILE__).'/' );
define('PLUG_URL', plugin_dir_url(__FILE__));


require_once ( 'helper/customiser-extra.php' );
require_once ( 'helper/customiser-metabox.php' );
require_once ( 'helper/cpt.php' );

?>