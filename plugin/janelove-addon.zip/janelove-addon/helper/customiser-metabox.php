<?php
function jl_custom_meta() {
    add_meta_box( 'jl_meta_ren', __( 'Course metabox', 'jlove' ), 'jl_meta_ren_callback', 'courses' );
}
add_action( 'add_meta_boxes', 'jl_custom_meta' );


function jl_meta_ren_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'jl_nounce' );

    $jl_stored = get_post_meta( $post->ID );
    ?>
 
    <p>
        <label for="jl_price"><?php _e( 'Price', 'jlove' )?></label>
        <input type="text" name="jl_price" id="jl_price" value="<?php if ( isset ( $jl_stored['jl_price'] ) ) echo $jl_stored['jl_price'][0]; ?>" />
    </p>

    <p>
        <label for="jl_discount"><?php _e( 'Discount', 'jlove' )?></label>
        <input type="text" name="jl_discount" id="jl_discount" value="<?php if ( isset ( $jl_stored['jl_discount'] ) ) echo $jl_stored['jl_discount'][0]; ?>" />
    </p>

    <p>
        <label for="jl_rating"><?php _e( 'Rating', 'jlove' )?></label>
        <input type="text" placeholder="rate 1-10" name="jl_rating" id="jl_rating" value="<?php if ( isset ( $jl_stored['jl_rating'] ) ) echo $jl_stored['jl_rating'][0]; ?>" />
    </p>

    <?php
}


function jl_save_meta( $post_id ) {
 
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'jl_nounce' ] ) && wp_verify_nonce( $_POST[ 'jl_nounce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
    if( isset( $_POST[ 'jl_price' ] ) ) {
        update_post_meta( $post_id, 'jl_price', sanitize_text_field( $_POST[ 'jl_price' ] ) );
    }
    if( isset( $_POST[ 'jl_discount' ] ) ) {
        update_post_meta( $post_id, 'jl_discount', sanitize_text_field( $_POST[ 'jl_discount' ] ) );
    }
    if( isset( $_POST[ 'jl_rating' ] ) ) {
        update_post_meta( $post_id, 'jl_rating', sanitize_text_field( $_POST[ 'jl_rating' ] ) );
    }

} 
add_action( 'save_post', 'jl_save_meta' );


add_action( 'customize_register', 'jl_register_theme_customizer' );

function jl_register_theme_customizer( $wp_customize ) {

    $wp_customize->add_panel( 'jl_block', array(
        'priority'       => 500,
        'theme_supports' => '',
        'title'          => __( 'Janelove Options', 'jlove' ),
    ) );

    $wp_customize->add_section( 'jlcounter' , array(
        'title'    => __('Counter','jlove'),
        'panel'    => 'jl_block',
        'priority' => 10
    ) );

    $wp_customize->add_setting( 'fcounter', array(
         'default'           => __( '<p class="num">500+</p><p class="context">Seamlessly synergize</p>', 'jlove' ),
    ) );

    $wp_customize->add_setting( 'scounter', array(
         'default'           => __( '<p class="num">500+</p><p class="context">Seamlessly synergize</p>', 'jlove' ),
    ) );

    $wp_customize->add_setting( 'tcounter', array(
         'default'           => __( '<p class="num">500+</p><p class="context">Seamlessly synergize</p>', 'jlove' ),
    ) );

    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'jlcounter',
            array(
                'label'    => __( 'First counter', 'jlove' ),
                'section'  => 'jlcounter',
                'settings' => 'fcounter',
                'type'     => 'textarea'
            )
        )
    );
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'jlcounter_2',
            array(
                'label'    => __( 'Second counter', 'jlove' ),
                'section'  => 'jlcounter',
                'settings' => 'scounter',
                'type'     => 'textarea'
            )
        )
    );

    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'jlcounter_3',
            array(
                'label'    => __( 'Second counter', 'jlove' ),
                'section'  => 'jlcounter',
                'settings' => 'tcounter',
                'type'     => 'textarea'
            )
        )
    );

}