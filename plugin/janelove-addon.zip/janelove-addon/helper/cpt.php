<?php
/**
 * Register course post type and custom taxonomy
 */
class Jl_Course_Post
{

    public function __construct()
    {

        add_action('init', array(&$this, 'create_post_type'));
        add_action('init', array(&$this, 'create_post_taxonomy'));
    }

    /**
     * create post type function
     * @return post type
     */

    public function create_post_type()
    {
        $labels = array(
            'name'               => __('Courses', 'janelove'),
            'singular_name'      => __('Course', 'janelove'),
            'add_new'            => __('Add New Courses', 'janelove'),
            'add_new_item'       => __('Add New Course', 'janelove'),
            'edit_item'          => __('Edit Course', 'janelove'),
            'new_item'           => __('New Course', 'janelove'),
            'all_items'          => __('All Courses', 'janelove'),
            'view_item'          => __('View Course', 'janelove'),
            'search_items'       => __('Search Course', 'janelove'),
            'not_found'          => __('No course found', 'janelove'),
            'not_found_in_trash' => __('No course found in the trash', 'janelove'),
            'parent_item_colon'  => '',
            'menu_name'          => __('Courses', 'janelove'),
        );
        $args = array(
            'labels'      => $labels,
            'public'      => true,
            'menu_icon'   => 'dashicons-awards',
            'supports'    => array('title', 'editor', 'thumbnail', 'excerpt'),
            'has_archive' => true,
        );
        register_post_type('courses', $args);
    }

    /**
     * create custom taxonomy
     * @return taxonomy
     */

    public function create_post_taxonomy()
    {
        $labels = array(
            'name'              => __('Course category', 'janelove'),
            'singular_name'     => __('Course Category', 'janelove'),
            'search_items'      => __('Search Course Categories', 'janelove'),
            'all_items'         => __('All Course Categories', 'janelove'),
            'parent_item'       => __('Parent Course Category', 'janelove'),
            'parent_item_colon' => __('Parent Course Category:', 'janelove'),
            'edit_item'         => __('Edit Course Category', 'janelove'),
            'update_item'       => __('Update Course Category', 'janelove'),
            'add_new_item'      => __('Add New Course Category', 'janelove'),
            'new_item_name'     => __('New Course Category', 'janelove'),
            'menu_name'         => __('Course Category', 'janelove'),
        );

        $args = array(
            'labels'            => $labels,
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => array('slug' => 'course-category'),
        );

        register_taxonomy('course-category', 'courses', $args);
    }

}

new Jl_Course_Post();
